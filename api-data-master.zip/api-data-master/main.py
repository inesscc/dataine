
from fastapi import FastAPI
import os
import re
import pandas as pd
from enum import Enum
from uvicorn.config import LOGGING_CONFIG
from fastapi import FastAPI, File, UploadFile
from fastapi.responses import HTMLResponse
import shutil
from fastapi import FastAPI, Request, HTTPException, Path
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl import load_workbook
import uvicorn
from time import time
import asyncio
import json
from slowapi.errors import RateLimitExceeded
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from typing_extensions import Annotated

description = """
**INE's data API** helps you get to work directly with INE's public datasets,
making your workflow easier and more reproducible. Currently you can get data from the following
datasets:
               
 * EPF (Encuesta de Presupuestos Familiares).

 * ENUSC (Encuesta Nacional Urbana de Seguridad Ciudadana).

 * ESI (Encuesta Suplementaria de Ingresos).

 * ENE (Encuesta Nacional de Empleo).
 """
from io import StringIO
# Inicializar
limiter = Limiter(key_func=get_remote_address)
app = FastAPI(title = "INE's data API",
              version='0.0.1',
              description=description)
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)

# Variables de validación
ALLOWED_EXTENSIONS =  ['feather', 'xlsx']
UPLOAD_PATHS = ["ene_test", "esi_test", "epf_personas", "epf_gastos", "enusc", '']

class TableNames(str, Enum):
    epf_gastos = 'epf_gastos'
    epf_personas = 'epf_personas'
    esi = 'esi'
    enusc = 'enusc'
    ene = 'ene'
# Mensaje de bienvenida a la api
@app.get("/")
def root():
    return {"message": "Welcome to INE's API"}


# Obtener listado de datasets con su respectivo identificador
# @app.get("/datasets") 
# async def get_dataset_list():
#       files_dic = {name: os.listdir("data/" + name) for name in os.listdir("data/") if
#                   'resumen_tablas' not in name}
#       files_dic2 = {k: [v.replace(".feather", "") for v in l if v.find("feather") != -1 ]  for k, l in files_dic.items()}
#       files_dic2 = {k: [re.sub(".*_", "", v) for v in l ]  for k, l in files_dic2.items()}
#       files_dic2  = {k:sorted(v) for k,v in files_dic2.items()}
#       return files_dic2

# Obtener  listado de datasets para una encuesta en específico
# @app.get('/datasets/{dataset}')
# async def get_specific_dataset_list(dataset: str ):
    
#     # if the validation fails the api throws an error
#     validate_dataset(dataset)
    
#     path = "data/{dataset}/".format(dataset = dataset)
#     files_dic = {dataset:os.listdir(path)}
#     files_dic2 = {k: [v.replace(".feather", "") for v in l if v.find("feather") != -1  ]  for k, l in files_dic.items()}
#     files_dic2 = {k: [re.sub(".*_", "", v) for v in l ]  for k, l in files_dic2.items()}
#     files_dic2  = {k:sorted(v) for k,v in files_dic2 .items()}
#     return files_dic2


def read_data(file):
    data = pd.read_feather(file).fillna("")

    # data2 = data.iloc[0:300 ]
    return data.to_json(orient='records')


# Obtener datos  de una encuesta en específico
@app.get('/data/{dataset}/{version}',
         description="Get a table in json format from INE's publicly available household surveys")
@limiter.limit("10/minute")
async def download_data(dataset: Annotated[TableNames, Path(description="The name of the table to get")],
                        version: Annotated[str, Path(description="The specific version of the table to get")],
                        request: Request):
    now = time()
    # if the validation fails the api throws an error
    validate_dataset(dataset)

    # If the validation fails an error is thrown    
    validate_version(dataset, version)

    file = "data/{dataset}/{dataset}_{year}.feather".format(dataset = dataset, year = version) #/home/klaus/ine/importine/
    now = time()
    loop = asyncio.get_event_loop()
    # cargamos datos (tarea síncrona) en paralelo, para que no interfiera con tareas asíncronas
    json_string = await loop.run_in_executor(None, read_data, file)
    print(time() - now)
    #json_string = json.dumps(json_data)
    return json_string


# Obtener columnas de un dataset
@app.get('/colnames/{dataset}/{version}')
def get_columns(dataset: TableNames, version: str):
    
    # if the validation fails the api throws an error
    validate_dataset(dataset)
    
    # If the validation fails an error is thrown    
    validate_version(dataset, version)
    
    file = "data/{dataset}/{dataset}_{year}.feather".format(dataset = dataset, year = version) #/home/klaus/ine/importine/
    data = pd.read_feather(file)
    cols = list(data.columns)
    json_data = {"data": cols}
    return  json_data



#  Subir archivo
@app.post('/upload')
async def create_file(request: Request):
    form = await request.form()
    filename = form['upload_file'].filename
    password = str(form["password"])
    folder = str(form["folder"])
    print(filename)
    print(folder)
    # Validar extensión archivo
    if allowed_file(filename) == False:
        raise HTTPException(status_code=404, detail="incorrect file format")
    # Validar contraseña
    elif password != "hola":
        raise HTTPException(status_code=404, detail="incorrect password")
    # Validar ruta de archivo
    elif validate_path(folder) == False:
        raise HTTPException(status_code=404, detail="incorrect directory")
    contents = await form['upload_file'].read()



    # Escribir archivo
    full_path = build_full_path(folder, filename)
    with open(filename, 'wb') as f:
        f.write(contents)

    shutil.copy(filename, full_path)

    save_summary_data(full_path, filename, folder)

    # Borrar archivo , para  no desordenar el directorio
    os.remove(filename)
    return filename, ALLOWED_EXTENSIONS, password, full_path


# Test the '/upload' endpoint using HTML <form>. 
# Access the form at 'http://127.0.0.1:8000/' from your browser 
@app.get('/uploadfile')
async def main():
    content = """
    <body>
    <form action="/upload" enctype="multipart/form-data" method="post">
    <input name="upload_file" type="file" required>
    <p>
      <label for="folder">folder:</label>
      <input type="text" name="folder" required>
    </p>
      <label for="clave">password:</label>
      <input type="text" name="password" required ></p> 
    <p>
    <p><input type="submit" value="Submit"></p>
    </form>
    </body>
    """
    return HTMLResponse(content=content)



############
# HERLPERS #
############


# Comprobar que el archivo tenga la extensión permitida
def allowed_file(filename):
     return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Validar la ruta para subir archivos
def validate_path(user_path):
     if user_path in UPLOAD_PATHS:
         return True
     else:
         return False

# Guardar tabla resumen
def save_summary_data(full_path, filename, folder):
    data_nueva = pd.read_feather(full_path)
    file_limpio = re.sub('\.feather', '', filename)
    resumen_file = pd.DataFrame({'survey': folder, 'version': [file_limpio], 'n_col': [data_nueva.shape[1]],
                                 'n_filas': [data_nueva.shape[0]]})
    wb = load_workbook(filename='data/resumen_tablas.xlsx')
    ws = wb["Sheet1"]

    versiones = pd.DataFrame(ws.values).iloc[1:, 1]
    if file_limpio not in versiones.values:
        print('Guardando datos resumen de tabla nueva')
        for r in dataframe_to_rows(resumen_file, index=False,
                                   header=False):  # No index and don't append the column headers
            ws.append(r)
    else:
        print('Datos resumen ya existían, se reemplazan con valores entregados ahora')
        row_dup = versiones[versiones == file_limpio].index.values[0]
        ws.cell(row=row_dup + 1, column=3).value = resumen_file.n_filas[0]
        ws.cell(row=row_dup + 1, column=4).value = resumen_file.n_col[0]

    wb.save('data/resumen_tablas.xlsx')
    
    
# Cargar tabla resumen para todos los datasets
@app.get("/datasets")
async def get_summary_data():
    resumen_datos = pd.read_excel('data/resumen_tablas.xlsx')
    json_data = resumen_datos.to_json(orient = 'records')
    return  json_data

# Cargar tabla resumen para datasets de una encuesta en específico
@app.get("/datasets/{dataset}")
async def get_specific_summary_data(dataset: str):
    
    # if the validation fails the api throws an error
    validate_dataset(dataset)
    
    resumen_datos = pd.read_excel('data/resumen_tablas.xlsx')
    resumen_datos_especificos = resumen_datos [resumen_datos.survey == dataset]
    json_data = resumen_datos_especificos.to_json(orient = 'records')
    return  json_data


# Construir la ruta para subir archivos
def build_full_path(user_path, filename):
     return "data/" + user_path + "/" + filename

# Buscar las encuestas disponibles
def get_available_surveys():
     files_dic = {name:os.listdir("data/" + name)  for name in os.listdir("data/") if
                        'resumen_tablas' not in name }
     files_dic2 = {k: [v.replace(".feather", "") for v in l if v.find("feather") != -1 ]  for k, l in files_dic.items()}
     files_dic2 = {k: [re.sub(".*_", "", v) for v in l ]  for k, l in files_dic2.items()}
     files_dic2  = {k:sorted(v) for k,v in files_dic2 .items()}
     return list(files_dic2.keys())

def get_available_versions(dataset):
    files_dic = {name:os.listdir("data/" + name)  for name in os.listdir("data/") if
                       'resumen_tablas' not in name} 
    files_dic2 = {k: [v.replace(".feather", "") for v in l if v.find("feather") != -1 ]  for k, l in files_dic.items()}
    files_dic2 = {k: [re.sub(".*_", "", v) for v in l ]  for k, l in files_dic2.items()}
    files_dic2  = {k:sorted(v) for k,v in files_dic2 .items()}
    return files_dic2[dataset]



def validate_dataset(dataset):
    if dataset not in get_available_surveys():
        message = "the {dataset} dataset is not available".format(dataset = dataset)
        raise HTTPException(status_code=404, detail=message)

def validate_version(dataset, version):    
    if version not in get_available_versions(dataset):
        message = "the version {version} is not available".format(version = version)
        raise HTTPException(status_code=404, detail=message)

if __name__ == "__main__":
    log_config = LOGGING_CONFIG
    log_config["formatters"]["access"]["fmt"] = "%(asctime)s - %(levelname)s - %(message)s"
    log_config["formatters"]["default"]["fmt"] = "%(asctime)s - %(levelname)s - %(message)s"
    uvicorn.run('main:app', host="127.0.0.1", port=8000, reload=True, log_config=log_config)
